import { useCallback, useEffect, useMemo, useState } from 'react';
import { StyleSheet, Text, View } from 'react-native';
import { Bubble, Composer, GiftedChat, InputToolbar, Send, type IMessage } from 'react-native-gifted-chat';

import { chatSocket } from '@/chat/socket';
import { palette } from '@/flow2/constants/theme';
import type { FlowChatMessage } from '@/flow2/data/types';
import { useApp } from '@/flow2/state/app';

type Props = {
  conversationId: string;
  role: 'customer' | 'vendor';
  recipient: string;
};

function toGiftedMessage(message: FlowChatMessage, role: Props['role']): IMessage {
  return {
    _id: message.id,
    text: message.text,
    createdAt: new Date(message.createdAt),
    user: {
      _id: message.sender,
      name: message.sender === role ? 'You' : role === 'customer' ? 'Vendor' : 'Customer',
    },
  };
}

export function RealtimeGiftedChat({ conversationId, role, recipient }: Props) {
  const { chatMessages, addChatMessage } = useApp();
  const [connection, setConnection] = useState<'connecting' | 'connected' | 'disconnected'>('disconnected');
  const messages = useMemo(
    () => (chatMessages[conversationId] ?? []).map((message) => toGiftedMessage(message, role)).sort((a, b) => Number(a.createdAt) - Number(b.createdAt)),
    [chatMessages, conversationId, role],
  );

  useEffect(() => {
    const stopMessages = chatSocket.subscribe((incoming) => {
      if (incoming.conversationId !== conversationId) return;
      const source = (incoming.from ?? '').toLowerCase();
      const isMine = incoming.is_mine ?? (source === role || (role === 'vendor' && source === 'provider'));
      const createdAt = incoming.created_at ? new Date(incoming.created_at).getTime() : Date.now();
      const message: FlowChatMessage = {
        id: String(incoming.client_id ?? incoming.id ?? `socket-${createdAt}-${Math.random()}`),
        text: incoming.message ?? incoming.text ?? '',
        createdAt: Number.isFinite(createdAt) ? createdAt : Date.now(),
        sender: isMine ? role : role === 'customer' ? 'vendor' : 'customer',
      };
      if (message.text) addChatMessage(conversationId, message);
    });
    const stopStatus = chatSocket.subscribeStatus(setConnection);
    chatSocket.connect();
    chatSocket.join(conversationId);
    return () => {
      chatSocket.leave(conversationId);
      stopMessages();
      stopStatus();
    };
  }, [addChatMessage, conversationId, role]);

  const onSend = useCallback((sent: IMessage[]) => {
    const message = sent[0];
    if (!message?.text.trim()) return;
    const clientId = String(message._id);
    addChatMessage(conversationId, {
      id: clientId,
      text: message.text.trim(),
      createdAt: +new Date(message.createdAt),
      sender: role,
    });
    chatSocket.relay(conversationId, message.text.trim(), role, clientId);
  }, [addChatMessage, conversationId, role]);

  return (
    <View style={styles.frame}>
      <View style={styles.liveBar}>
        <View style={[styles.dot, connection === 'connected' ? styles.online : connection === 'connecting' ? styles.connecting : styles.offline]} />
        <Text style={styles.liveText}>{connection === 'connected' ? 'Live' : connection === 'connecting' ? 'Connecting…' : 'Offline · retrying'}</Text>
        <Text numberOfLines={1} style={styles.recipient}>{recipient}</Text>
      </View>
      <GiftedChat
        messages={messages}
        inverted={false}
        onSend={onSend}
        user={{ _id: role, name: role === 'customer' ? 'Customer' : 'Vendor' }}
        placeholder="Message…"
        alwaysShowSend
        isKeyboardInternallyHandled={false}
        keyboardShouldPersistTaps="handled"
        listViewProps={{ showsVerticalScrollIndicator: false }}
        timeTextStyle={{ left: { color: palette.muted }, right: { color: palette.accentDark } }}
        messagesContainerStyle={styles.messages}
        textInputProps={{ selectionColor: palette.accent, placeholderTextColor: palette.muted }}
        renderBubble={(props) => (
          <Bubble
            {...props}
            wrapperStyle={{ left: styles.incomingBubble, right: styles.outgoingBubble }}
            textStyle={{ left: styles.incomingText, right: styles.outgoingText }}
          />
        )}
        renderInputToolbar={(props) => <InputToolbar {...props} containerStyle={styles.toolbar} primaryStyle={styles.toolbarPrimary} />}
        renderComposer={(props) => <Composer {...props} textInputStyle={styles.composer} />}
        renderSend={(props) => (
          <Send {...props} containerStyle={styles.sendContainer}>
            <View style={styles.sendButton}><Text style={styles.sendText}>Send</Text></View>
          </Send>
        )}
        renderChatEmpty={() => (
          <View style={styles.empty}>
            <Text style={styles.emptyTitle}>Start the conversation</Text>
            <Text style={styles.emptyBody}>Keep event details and updates in one place.</Text>
          </View>
        )}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  frame: { flex: 1, backgroundColor: palette.bg },
  liveBar: { minHeight: 34, paddingHorizontal: 14, flexDirection: 'row', alignItems: 'center', gap: 7, backgroundColor: '#FFFFFF' },
  dot: { width: 7, height: 7, borderRadius: 4 },
  online: { backgroundColor: palette.accent },
  connecting: { backgroundColor: '#E8A93A' },
  offline: { backgroundColor: '#C35858' },
  liveText: { color: palette.muted, fontSize: 12, fontWeight: '700' },
  recipient: { flex: 1, textAlign: 'right', color: palette.muted, fontSize: 12 },
  messages: { backgroundColor: palette.bg },
  incomingBubble: { backgroundColor: '#FFFFFF', borderRadius: 16, borderBottomLeftRadius: 5, paddingHorizontal: 3, paddingVertical: 2 },
  outgoingBubble: { backgroundColor: palette.accentSoft, borderRadius: 16, borderBottomRightRadius: 5, paddingHorizontal: 3, paddingVertical: 2 },
  incomingText: { color: palette.ink, fontSize: 15, lineHeight: 21 },
  outgoingText: { color: palette.ink, fontSize: 15, lineHeight: 21 },
  toolbar: { borderTopColor: palette.line, borderTopWidth: 1, backgroundColor: palette.surface, paddingHorizontal: 10, paddingVertical: 8 },
  toolbarPrimary: { flexDirection: 'row', alignItems: 'center', gap: 8 },
  composer: { minHeight: 42, maxHeight: 110, borderRadius: 22, backgroundColor: palette.well, paddingHorizontal: 15, paddingTop: 10, paddingBottom: 8, marginLeft: 0, marginBottom: 0, marginTop: 0, fontSize: 16 },
  sendContainer: { minWidth: 62, height: 42, alignItems: 'center', justifyContent: 'center' },
  sendButton: { minWidth: 58, height: 38, paddingHorizontal: 12, borderRadius: 20, backgroundColor: palette.accent, alignItems: 'center', justifyContent: 'center' },
  sendText: { color: '#FFFFFF', fontSize: 14, fontWeight: '800' },
  // GiftedChat flips its empty wrapper even when the message list is not inverted.
  empty: { flex: 1, minWidth: '100%', alignItems: 'center', justifyContent: 'center', transform: [{ scaleY: -1 }], padding: 24 },
  emptyTitle: { color: palette.ink, fontSize: 17, fontWeight: '800' },
  emptyBody: { color: palette.muted, textAlign: 'center', marginTop: 5 },
});
