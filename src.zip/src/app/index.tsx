import { router } from 'expo-router';
import { StyleSheet, Text, View } from 'react-native';

import { Button } from '@/flow2/components/Button';
import { Screen } from '@/flow2/components/Screen';
import { palette } from '@/flow2/constants/theme';
import { useApp } from '@/flow2/state/app';

export default function RoleSelectionScreen() {
  const { onboarding, setRole } = useApp();

  const openCustomer = () => {
    setRole('customer');
    router.push('/customer/auth' as any);
  };

  const openVendor = () => {
    setRole('vendor');
    router.push((onboarding.status === 'approved' ? '/vendor' : '/vendor/onboarding') as any);
  };

  return (
    <Screen scroll={false} style={styles.screen}>
      <View style={styles.content}>
        <Text style={styles.appName}>ServioSpot</Text>
        <View style={styles.buttons}>
          <Button label="Customer" onPress={openCustomer} style={styles.button} />
          <Button label="Vendor" variant="secondary" onPress={openVendor} style={styles.button} />
        </View>
      </View>
    </Screen>
  );
}

const styles = StyleSheet.create({
  screen: { flex: 1, justifyContent: 'center', gap: 0 },
  content: { width: '100%', alignItems: 'center', gap: 28 },
  appName: { color: palette.ink, fontSize: 36, fontWeight: '800', letterSpacing: -1.2 },
  buttons: { width: '100%', maxWidth: 360, gap: 14 },
  button: { minHeight: 56, borderRadius: 16 },
});
